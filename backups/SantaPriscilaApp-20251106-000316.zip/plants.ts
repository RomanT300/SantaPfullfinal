import { Router, type Request, type Response } from 'express'
import { supabaseClient } from '../lib/supabase.js'
import { requireAuth, requireAdmin } from '../middleware/auth.js'
import { body, validationResult } from 'express-validator'

const router = Router()

router.get('/', requireAuth, async (_req: Request, res: Response) => {
  const { data, error } = await supabaseClient
    .from('plants')
    .select('*')
    .order('name', { ascending: true })
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, data })
})

router.post(
  '/',
  requireAuth,
  requireAdmin,
  [body('name').isString(), body('location').isString(), body('latitude').isFloat(), body('longitude').isFloat()],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() })
    const { name, location, latitude, longitude, status = 'active' } = req.body
    const { data, error } = await supabaseClient
      .from('plants')
      .insert({ name, location, latitude, longitude, status })
      .select()
      .single()
    if (error) return res.status(400).json({ success: false, error: error.message })
    res.status(201).json({ success: true, data })
  },
)

export default router