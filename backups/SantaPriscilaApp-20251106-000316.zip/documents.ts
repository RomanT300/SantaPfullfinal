import { Router, type Request, type Response } from 'express'
import multer from 'multer'
import path from 'path'
import { supabaseClient } from '../lib/supabase.js'
import { requireAuth, requireAdmin } from '../middleware/auth.js'

const router = Router()

// local disk storage for MVP; can be swapped to Supabase Storage
const uploadDir = path.join(process.cwd(), 'uploads')
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, Date.now() + '-' + file.originalname),
})
const maxSize = Number(process.env.MAX_FILE_SIZE || process.env.UPLOAD_MAX_FILE_SIZE || 10 * 1024 * 1024)
const allowedMimes = new Set(['application/pdf', 'image/png', 'image/jpeg'])
const upload = multer({
  storage,
  limits: { fileSize: maxSize },
  fileFilter: (_req, file, cb) => {
    if (allowedMimes.has(file.mimetype)) cb(null, true)
    else cb(new Error('Invalid file type'))
  },
})

// GET /api/documents
router.get('/', requireAuth, async (_req: Request, res: Response) => {
  const { data, error } = await supabaseClient
    .from('documents')
    .select('*')
    .order('uploaded_at', { ascending: false })
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, data })
})

// POST /api/documents/upload (admin only)
router.post('/upload', requireAuth, requireAdmin, upload.single('file'), async (req: Request, res: Response) => {
  const file = (req as any).file
  const { plantId, category, description } = req.body
  if (!file || !plantId || !category) {
    return res.status(400).json({ success: false, error: 'Missing file/plantId/category' })
  }
  const { data, error } = await supabaseClient
    .from('documents')
    .insert({
      plant_id: plantId,
      file_name: file.originalname,
      file_path: `/uploads/${file.filename}`,
      category,
      description,
      uploaded_by: (req as any).user?.sub,
    })
    .select()
    .single()
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.status(201).json({ success: true, data })
})

export default router