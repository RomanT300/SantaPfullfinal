import { useState } from 'react'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!json.success) throw new Error(json.error || 'Login failed')
      // El JWT se guarda en cookie HttpOnly desde el backend
      window.location.href = '/dashboard'
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Iniciar sesión</h1>
      <form onSubmit={submit} className="space-y-3">
        <input className="w-full border px-3 py-2 rounded" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input className="w-full border px-3 py-2 rounded" type="password" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <div className="text-red-600 text-sm">{error}</div>}
        <button disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded">{loading ? 'Entrando...' : 'Entrar'}</button>
      </form>
      {import.meta.env.DEV && (
        <div className="mt-6 border-t pt-4">
          <p className="text-sm text-gray-600 mb-2">Acceso rápido de demostración</p>
          <div className="flex gap-3">
            <button
              className="bg-emerald-600 text-white px-3 py-2 rounded text-sm"
              onClick={() => {
                // Token pre-firmado con secreto 'dev-secret' y rol admin (válido 12h)
                const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsb2NhbC1hZG1pbiIsImVtYWlsIjoiYWRtaW5AZGVtbyIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2MjQwNDA2NiwiZXhwIjoxNzYyNDQ3MjY2fQ.N_ViIFFMU_1FSjvf_c8VoU0eohASXAJGSvQjJrzc7Yw'
                localStorage.setItem('token', token)
                window.location.href = '/emergencies'
              }}
            >
              Entrar como Admin demo
            </button>
          </div>
          <p className="text-xs text-yellow-700 bg-yellow-50 border rounded p-2 mt-3">
            Nota: el botón de demo está pensado para pruebas locales y activa el rol "Admin" en la interfaz. Para producción, usa registro y login reales.
          </p>
        </div>
      )}
    </div>
  )
}