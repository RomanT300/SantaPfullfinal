import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import Header from "@/components/Header";
import Dashboard from "@/pages/Dashboard";
import Maintenance from "@/pages/Maintenance";
import Documents from "@/pages/Documents";
import MapPage from "@/pages/Map";
import Admin from "@/pages/Admin";
import Login from "@/pages/Login";
import Emergencies from "@/pages/Emergencies";

export default function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/maintenance" element={<Maintenance />} />
        <Route path="/emergencies" element={<Emergencies />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/map" element={<MapPage />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}
