import { useEffect, useState } from 'react'
import { FileText, Download } from 'lucide-react'

type Doc = {
  id: string
  file_name: string
  file_path: string
  category: string
  uploaded_at: string
}

export default function Documents() {
  const [docs, setDocs] = useState<Doc[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/documents', { credentials: 'include' })
      .then(r => r.json())
      .then(json => {
        if (!json.success) throw new Error(json.error || 'Error')
        setDocs(json.data || [])
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Repositorio Documental</h1>
      </div>
      {loading && <div>Cargando...</div>}
      {error && <div className="text-red-600">{error}</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {docs.map(d => (
          <div key={d.id} className="bg-white dark:bg-gray-800 border rounded-lg p-4 shadow-sm hover:shadow-md transition">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded bg-blue-50 dark:bg-blue-900/50 text-blue-600"><FileText /></div>
              <div className="flex-1">
                <div className="font-medium truncate">{d.file_name}</div>
                <div className="text-xs text-gray-500">Categoría: {d.category}</div>
                <div className="text-xs text-gray-500">{new Date(d.uploaded_at).toLocaleString()}</div>
              </div>
              <a href={d.file_path} target="_blank" rel="noreferrer" className="px-3 py-2 rounded border text-sm flex items-center gap-1">
                <Download size={14}/> Descargar
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}