/**
 * This is a user authentication API route demo.
 * Handle user registration, login, token management, etc.
 */
import { Router, type Request, type Response } from 'express'
import jwt from 'jsonwebtoken'
import { supabaseAdmin, supabaseClient } from '../lib/supabase.js'
import { authLimiter } from '../middleware/rateLimit.js'
import type { CookieOptions } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { body, validationResult } from 'express-validator'

const router = Router()
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret'

/**
 * User Login
 * POST /api/auth/register
 */
router.post(
  '/register',
  authLimiter,
  [
    body('email').isEmail(),
    body('password').isLength({ min: 8 }),
    body('name').isString().isLength({ min: 2 }),
    body('role').optional().isIn(['admin', 'standard']),
  ],
  async (req: Request, res: Response): Promise<void> => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      res.status(400).json({ success: false, errors: errors.array() })
      return
    }
    const { email, password, name, role = 'standard' } = req.body
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, role },
    })
    if (error) {
      res.status(400).json({ success: false, error: error.message })
      return
    }
    res.status(201).json({ success: true, user: data.user })
  },
)

/**
 * User Login
 * POST /api/auth/login
 */
router.post(
  '/login',
  authLimiter,
  [body('email').isEmail(), body('password').isString()],
  async (req: Request, res: Response): Promise<void> => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      res.status(400).json({ success: false, errors: errors.array() })
      return
    }
    const { email, password } = req.body
    const { data, error } = await supabaseClient.auth.signInWithPassword({
      email,
      password,
    })
    if (error || !data.user || !data.session) {
      res.status(401).json({ success: false, error: error?.message || 'Invalid credentials' })
      return
    }
    const role = (data.user.user_metadata as any)?.role || 'standard'
    const token = jwt.sign(
      { sub: data.user.id, email: data.user.email, role },
      JWT_SECRET,
      { expiresIn: '12h' },
    )
    const isProd = process.env.NODE_ENV === 'production'
    const cookieOptions: CookieOptions = {
      httpOnly: true,
      secure: isProd,
      sameSite: isProd ? 'lax' : 'strict',
      path: '/',
      maxAge: 12 * 60 * 60 * 1000,
    }
    res.cookie('token', token, cookieOptions)
    res.status(200).json({
      success: true,
      user: { id: data.user.id, email: data.user.email, role },
      token,
      refreshToken: data.session.refresh_token,
    })
  },
)

/**
 * User Logout
 * POST /api/auth/logout
 */
router.post('/logout', async (req: Request, res: Response): Promise<void> => {
  // Client-side should discard tokens; invalidate refresh if needed
  res.status(200).json({ success: true })
})

/**
 * Current user info (from JWT cookie or Authorization header)
 * GET /api/auth/me
 */
router.get('/me', requireAuth, async (req: Request, res: Response): Promise<void> => {
  const user = (req as any).user
  res.status(200).json({ success: true, user })
})

export default router
