import { Router, type Request, type Response } from 'express'
import { supabaseClient } from '../lib/supabase.js'
import { requireAuth, requireAdmin } from '../middleware/auth.js'
import { writeLimiter } from '../middleware/rateLimit.js'
import { body, validationResult } from 'express-validator'

const router = Router()

// GET /api/maintenance/tasks
router.get('/tasks', requireAuth, async (_req: Request, res: Response) => {
  const { data, error } = await supabaseClient
    .from('maintenance_tasks')
    .select('*')
    .order('scheduled_date', { ascending: true })
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, data })
})

// POST /api/maintenance/tasks (admin only)
router.post(
  '/tasks',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [
    body('plantId').isString(),
    body('type').isIn(['preventive', 'corrective', 'general']),
    body('scheduledDate').isISO8601(),
    body('description').isString(),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const { plantId, type, scheduledDate, description } = req.body
    const { data, error } = await supabaseClient
      .from('maintenance_tasks')
      .insert({ plant_id: plantId, task_type: type, scheduled_date: scheduledDate, description })
      .select()
      .single()
    if (error) return res.status(400).json({ success: false, error: error.message })
    res.status(201).json({ success: true, data })
  },
)

// POST /api/maintenance/tasks/generate-monthly (admin only)
router.post(
  '/tasks/generate-monthly',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [body('year').optional().isInt({ min: 2000, max: 2100 })],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const year = Number((req.body?.year ?? new Date().getFullYear()))
    // Obtener todas las plantas
    const { data: plants, error: plantsError } = await supabaseClient
      .from('plants')
      .select('id')
    if (plantsError) return res.status(400).json({ success: false, error: plantsError.message })
    const plantIds: string[] = Array.isArray(plants) ? plants.map((p: any) => p.id) : []
    if (plantIds.length === 0) return res.status(200).json({ success: true, inserted: 0, message: 'No plants found' })

    // Consultar tareas existentes del año para evitar duplicados por (plant_id, scheduled_date)
    const start = new Date(year, 0, 1).toISOString()
    const end = new Date(year, 11, 31, 23, 59, 59, 999).toISOString()
    const { data: existing, error: exError } = await supabaseClient
      .from('maintenance_tasks')
      .select('plant_id, scheduled_date')
      .gte('scheduled_date', start)
      .lte('scheduled_date', end)
    if (exError) return res.status(400).json({ success: false, error: exError.message })
    const existingKeys = new Set<string>((existing || []).map((r: any) => `${r.plant_id}|${r.scheduled_date.slice(0,10)}`))
    const plantsWithAnyTask = new Set<string>((existing || []).map((r: any) => r.plant_id))

    const toInsert: any[] = []
    plantIds.forEach(pid => {
      // Inserta una única tarea por planta si no existe ninguna para ese año
      if (!plantsWithAnyTask.has(pid)) {
        toInsert.push({
          plant_id: pid,
          task_type: 'general',
          description: 'Mantenimiento completo',
          scheduled_date: new Date(year, 6, 1).toISOString(), // 1 de julio
          status: 'pending',
        })
      }
    })

    if (toInsert.length === 0) {
      return res.status(200).json({ success: true, inserted: 0, message: 'No new tasks to insert' })
    }

    const { data: insData, error: insError } = await supabaseClient
      .from('maintenance_tasks')
      .insert(toInsert)
      .select()
    if (insError) return res.status(400).json({ success: false, error: insError.message })
    res.status(201).json({ success: true, inserted: Array.isArray(insData) ? insData.length : 0, data: insData })
  },
)

// --- Emergencies endpoints ---
// GET /api/maintenance/emergencies
router.get('/emergencies', requireAuth, async (_req: Request, res: Response) => {
  const { data, error } = await supabaseClient
    .from('maintenance_emergencies')
    .select('*')
    .order('reported_at', { ascending: false })
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, data })
})

// POST /api/maintenance/emergencies (admin only)
router.post(
  '/emergencies',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [
    body('plantId').isString(),
    body('reason').isString(),
    body('solved').optional().isBoolean(),
    body('resolveTimeHours').optional().isInt({ min: 0 }),
    body('reportedAt').optional().isISO8601(),
    body('severity').optional().isIn(['low', 'medium', 'high']),
    body('resolvedAt').optional().isISO8601(),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const { plantId, reason, solved = false, resolveTimeHours = null, reportedAt = new Date().toISOString(), severity, resolvedAt } = req.body
    const payloadWithExtras: any = {
      plant_id: plantId,
      reason,
      solved,
      resolve_time_hours: resolveTimeHours,
      reported_at: reportedAt,
    }
    if (typeof severity !== 'undefined') payloadWithExtras.severity = severity
    if (typeof resolvedAt !== 'undefined') payloadWithExtras.resolved_at = resolvedAt

    // Intento con campos extra; si falla por columnas inexistentes, reintento sin ellos
    let insert = await supabaseClient
      .from('maintenance_emergencies')
      .insert(payloadWithExtras)
      .select()
      .single()
    if (insert.error) {
      const fallbackPayload: any = {
        plant_id: plantId,
        reason,
        solved,
        resolve_time_hours: resolveTimeHours,
        reported_at: reportedAt,
      }
      insert = await supabaseClient
        .from('maintenance_emergencies')
        .insert(fallbackPayload)
        .select()
        .single()
    }
    if (insert.error) return res.status(400).json({ success: false, error: insert.error.message })
    res.status(201).json({ success: true, data: insert.data })
  },
)

// PATCH /api/maintenance/emergencies/:id (admin only)
router.patch(
  '/emergencies/:id',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [
    body('plantId').optional().isString(),
    body('reason').optional().isString(),
    body('solved').optional().isBoolean(),
    body('resolveTimeHours').optional().isInt({ min: 0 }),
    body('severity').optional().isIn(['low', 'medium', 'high']),
    body('resolvedAt').optional().isISO8601(),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const id = req.params.id
    const { plantId, reason, solved, resolveTimeHours, severity, resolvedAt } = req.body
    const updates: any = {}
    if (plantId !== undefined) updates.plant_id = plantId
    if (reason !== undefined) updates.reason = reason
    if (solved !== undefined) updates.solved = solved
    if (resolveTimeHours !== undefined) updates.resolve_time_hours = resolveTimeHours
    if (severity !== undefined) updates.severity = severity
    if (resolvedAt !== undefined) updates.resolved_at = resolvedAt

    let update = await supabaseClient
      .from('maintenance_emergencies')
      .update(updates)
      .eq('id', id)
      .select()
      .single()
    if (update.error) {
      const fallbackUpdates: any = {}
      if (plantId !== undefined) fallbackUpdates.plant_id = plantId
      if (reason !== undefined) fallbackUpdates.reason = reason
      if (solved !== undefined) fallbackUpdates.solved = solved
      if (resolveTimeHours !== undefined) fallbackUpdates.resolve_time_hours = resolveTimeHours
      update = await supabaseClient
        .from('maintenance_emergencies')
        .update(fallbackUpdates)
        .eq('id', id)
        .select()
        .single()
    }
    if (update.error) return res.status(400).json({ success: false, error: update.error.message })
    res.json({ success: true, data: update.data })
  },
)

export default router

// PATCH /api/maintenance/tasks/:id - actualizar estado y fecha de realización
router.patch(
  '/tasks/:id',
  requireAuth,
  writeLimiter,
  [
    body('status').optional().isIn(['pending', 'completed', 'overdue']),
    body('completedDate').optional().isISO8601(),
    body('scheduledDate').optional().isISO8601(),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() })
    const id = req.params.id
    const { status, completedDate, scheduledDate } = req.body as { status?: string; completedDate?: string; scheduledDate?: string }
    const user = (req as any).user
    // Solo admin puede editar fecha planificada
    if (typeof scheduledDate !== 'undefined' && (!user || user.role !== 'admin')) {
      return res.status(403).json({ success: false, error: 'Forbidden: only admin can edit scheduledDate' })
    }
    const payload: Record<string, any> = {}
    if (status) payload.status = status
    // Si completedDate es null, limpiamos el campo
    if (typeof completedDate !== 'undefined') payload.completed_date = completedDate || null
    if (typeof scheduledDate !== 'undefined') payload.scheduled_date = scheduledDate
    const { data, error } = await supabaseClient
      .from('maintenance_tasks')
      .update(payload)
      .eq('id', id)
      .select()
    if (error) return res.status(400).json({ success: false, error: error.message })
    res.json({ success: true, data: Array.isArray(data) ? data[0] : data })
  },
)

// DELETE /api/maintenance/tasks/:id (admin only)
router.delete('/tasks/:id', requireAuth, requireAdmin, writeLimiter, async (req: Request, res: Response) => {
  const id = req.params.id
  const { error } = await supabaseClient
    .from('maintenance_tasks')
    .delete()
    .eq('id', id)
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, deleted: 1 })
})

// DELETE /api/maintenance/emergencies/:id (admin only)
router.delete('/emergencies/:id', requireAuth, requireAdmin, writeLimiter, async (req: Request, res: Response) => {
  const id = req.params.id
  const { error } = await supabaseClient
    .from('maintenance_emergencies')
    .delete()
    .eq('id', id)
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, deleted: 1 })
})