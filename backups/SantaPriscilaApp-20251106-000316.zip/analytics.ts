import { Router, type Request, type Response } from 'express'
import { supabaseClient } from '../lib/supabase.js'
import { requireAuth, requireAdmin } from '../middleware/auth.js'
import { writeLimiter } from '../middleware/rateLimit.js'
import { body, validationResult } from 'express-validator'

const router = Router()

// GET /api/analytics/environmental
router.get('/environmental', requireAuth, async (req: Request, res: Response) => {
  const { plantId, startDate, endDate, parameter, stream } = req.query as Record<string, string>
  const base = supabaseClient
    .from('environmental_data')
    .select('*')
    .order('measurement_date', { ascending: true })

  let baseQuery = base
  if (plantId) baseQuery = baseQuery.eq('plant_id', plantId)
  if (parameter) baseQuery = baseQuery.eq('parameter_type', parameter)
  if (startDate) baseQuery = baseQuery.gte('measurement_date', startDate)
  if (endDate) baseQuery = baseQuery.lte('measurement_date', endDate)

  // Intentamos filtrar por 'stream' si se envía, con fallback si la columna no existe
  let data: any = null
  let error: any = null
  if (stream) {
    const { data: d1, error: e1 } = await baseQuery.eq('stream', stream)
    if (e1) {
      // Fallback: volvemos a consultar sin el filtro 'stream'
      const { data: d2, error: e2 } = await baseQuery
      data = d2
      error = e2
    } else {
      data = d1
      error = e1
    }
  } else {
    const { data: d, error: e } = await baseQuery
    data = d
    error = e
  }
  if (error) return res.status(400).json({ success: false, error: error.message })

  const summary = Array.isArray(data)
    ? data.reduce<Record<string, any>>((acc, row: any) => {
        const key = row.parameter_type
        acc[key] = acc[key] || { count: 0, sum: 0, min: row.value, max: row.value }
        acc[key].count++
        acc[key].sum += Number(row.value)
        acc[key].min = Math.min(acc[key].min, Number(row.value))
        acc[key].max = Math.max(acc[key].max, Number(row.value))
        return acc
      }, {})
    : {}

  Object.keys(summary).forEach(k => {
    const s = summary[k]
    s.avg = s.count ? s.sum / s.count : 0
  })

  res.json({ success: true, data, summary })
})

// POST /api/analytics/environmental (admin only) - insert or update a measurement
router.post(
  '/environmental',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [
    body('plantId').isString(),
    body('parameter').isIn(['DQO', 'pH', 'SS']),
    body('measurementDate').isISO8601(),
    body('value').isFloat({ min: 0 }),
    body('stream').optional().isIn(['influent', 'effluent']),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const { plantId, parameter, measurementDate, value, stream } = req.body
    // Try to find existing row with exact keys
    let existing: any = await supabaseClient
      .from('environmental_data')
      .select('id')
      .eq('plant_id', plantId)
      .eq('parameter_type', parameter)
      .eq('measurement_date', measurementDate)
      .eq('stream', stream ?? null)
      .maybeSingle()

    if (existing.error) {
      // Fallback without stream filter if column not present
      existing = await supabaseClient
        .from('environmental_data')
        .select('id')
        .eq('plant_id', plantId)
        .eq('parameter_type', parameter)
        .eq('measurement_date', measurementDate)
        .maybeSingle()
    }

    if (existing.data?.id) {
      // Update
      let update = await supabaseClient
        .from('environmental_data')
        .update({ value, ...(typeof stream !== 'undefined' ? { stream } : {}) })
        .eq('id', existing.data.id)
        .select()
        .single()
      if (update.error) return res.status(400).json({ success: false, error: update.error.message })
      return res.json({ success: true, data: update.data, updated: 1 })
    } else {
      // Insert
      const payload: any = {
        plant_id: plantId,
        parameter_type: parameter,
        measurement_date: measurementDate,
        value,
      }
      if (typeof stream !== 'undefined') payload.stream = stream
      const { data: ins, error: insError } = await supabaseClient
        .from('environmental_data')
        .insert(payload)
        .select()
        .single()
      if (insError) return res.status(400).json({ success: false, error: insError.message })
      return res.status(201).json({ success: true, data: ins, inserted: 1 })
    }
  }
)

export default router

// DELETE /api/analytics/environmental/:id (admin only)
router.delete('/environmental/:id', requireAuth, requireAdmin, writeLimiter, async (req: Request, res: Response) => {
  const id = req.params.id
  const { error } = await supabaseClient
    .from('environmental_data')
    .delete()
    .eq('id', id)
  if (error) return res.status(400).json({ success: false, error: error.message })
  res.json({ success: true, deleted: 1 })
})

// DELETE /api/analytics/environmental (admin only) by keys
router.delete(
  '/environmental',
  requireAuth,
  requireAdmin,
  writeLimiter,
  [
    body('plantId').isString(),
    body('parameter').isIn(['DQO', 'pH', 'SS']),
    body('measurementDate').isISO8601(),
    body('stream').optional().isIn(['influent', 'effluent']),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() })
    }
    const { plantId, parameter, measurementDate, stream } = req.body
    let existing: any = await supabaseClient
      .from('environmental_data')
      .select('id')
      .eq('plant_id', plantId)
      .eq('parameter_type', parameter)
      .eq('measurement_date', measurementDate)
      .eq('stream', stream ?? null)
      .maybeSingle()

    if (existing.error) {
      existing = await supabaseClient
        .from('environmental_data')
        .select('id')
        .eq('plant_id', plantId)
        .eq('parameter_type', parameter)
        .eq('measurement_date', measurementDate)
        .maybeSingle()
    }
    const id = existing.data?.id
    if (!id) return res.status(404).json({ success: false, error: 'Measurement not found' })
    const { error } = await supabaseClient
      .from('environmental_data')
      .delete()
      .eq('id', id)
    if (error) return res.status(400).json({ success: false, error: error.message })
    res.json({ success: true, deleted: 1 })
  }
)