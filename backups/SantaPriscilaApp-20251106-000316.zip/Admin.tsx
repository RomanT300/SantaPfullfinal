import { useEffect, useState } from 'react'

type Plant = { id: string; name: string }

export default function Admin() {
  const [plants, setPlants] = useState<Plant[]>([])
  const [plantId, setPlantId] = useState<string>('')
  const [parameter, setParameter] = useState<'DQO'|'pH'|'SS'>('DQO')
  const [stream, setStream] = useState<'influent'|'effluent'>('influent')
  const [measurementDate, setMeasurementDate] = useState<string>('')
  const [value, setValue] = useState<string>('1000')
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<string>('')

  // Demo storage fallback helpers
  const readDemo = (): any[] => {
    try {
      return JSON.parse(localStorage.getItem('env_demo') || '[]')
    } catch {
      return []
    }
  }
  const writeDemo = (rows: any[]) => {
    localStorage.setItem('env_demo', JSON.stringify(rows))
  }
  const upsertDemo = (r: { plant_id: string; parameter_type: string; measurement_date: string; value: number; stream?: 'influent'|'effluent' }) => {
    const list = readDemo()
    const idx = list.findIndex((x: any) => x.plant_id === r.plant_id && x.parameter_type === r.parameter_type && x.measurement_date === r.measurement_date && (x.stream ?? null) === (r.stream ?? null))
    if (idx >= 0) {
      list[idx] = { ...list[idx], value: r.value, ...(typeof r.stream !== 'undefined' ? { stream: r.stream } : {}) }
    } else {
      list.push({ id: `local-${Date.now()}`, ...r })
    }
    writeDemo(list)
  }
  const deleteDemo = (keys: { plant_id: string; parameter_type: string; measurement_date: string; stream?: 'influent'|'effluent' }) => {
    const list = readDemo()
    const next = list.filter((x: any) => !(x.plant_id === keys.plant_id && x.parameter_type === keys.parameter_type && x.measurement_date === keys.measurement_date && (x.stream ?? null) === (keys.stream ?? null)))
    writeDemo(next)
  }

  useEffect(() => {
    fetch('/api/plants', { credentials: 'include' })
      .then(r=>r.json()).then(json=>{ if(json.success) setPlants(json.data || []) })
      .catch(()=>{
        setPlants([
          { id: 'LA LUZ', name: 'LA LUZ' },
          { id: 'TAURA', name: 'TAURA' },
          { id: 'SANTA MONICA', name: 'SANTA MONICA' },
          { id: 'SAN DIEGO', name: 'SAN DIEGO' },
          { id: 'CHANDUY', name: 'CHANDUY' },
        ])
      })
  }, [])

  const saveMeasurement = async () => {
    setSaving(true)
    setMessage('')
    try {
      const resp = await fetch('/api/analytics/environmental', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ plantId, parameter, stream, measurementDate, value: Number(value) }),
      })
      const json = await resp.json()
      if (!json.success) throw new Error(json.error || 'Error')
      setMessage('Guardado correctamente')
    } catch (e: any) {
      // fallback demo local
      upsertDemo({
        plant_id: plantId,
        parameter_type: parameter,
        measurement_date: measurementDate,
        value: Number(value),
        stream,
      })
      setMessage('Guardado en modo demo (local)')
    } finally {
      setSaving(false)
    }
  }

  const deleteMeasurement = async () => {
    setSaving(true)
    setMessage('')
    try {
      const resp = await fetch('/api/analytics/environmental', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ plantId, parameter, stream, measurementDate }),
      })
      const json = await resp.json()
      if (!json.success) throw new Error(json.error || 'Error')
      setMessage('Eliminado correctamente')
    } catch (e: any) {
      // fallback demo local
      deleteDemo({
        plant_id: plantId,
        parameter_type: parameter,
        measurement_date: measurementDate,
        stream,
      })
      setMessage('Eliminado en modo demo (local)')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      <h1 className="text-2xl font-semibold mb-4">Panel de Administración</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded border p-4">
          <h2 className="text-lg font-medium mb-3">Editar analíticas ambientales</h2>
          <div className="space-y-3">
            <label className="block text-sm">Planta</label>
            <select value={plantId} onChange={e=>setPlantId(e.target.value)} className="px-3 py-2 rounded border w-full bg-white dark:bg-gray-800">
              <option value="">Selecciona planta</option>
              {plants.map(pl=> <option key={pl.id} value={pl.id}>{pl.name}</option>)}
            </select>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm">Parámetro</label>
                <select value={parameter} onChange={e=>setParameter(e.target.value as any)} className="px-3 py-2 rounded border w-full bg-white dark:bg-gray-800">
                  <option value="DQO">DQO</option>
                  <option value="pH">pH</option>
                  <option value="SS">SS</option>
                </select>
              </div>
              <div>
                <label className="block text-sm">Flujo</label>
                <select value={stream} onChange={e=>setStream(e.target.value as any)} className="px-3 py-2 rounded border w-full bg-white dark:bg-gray-800">
                  <option value="influent">Afluente</option>
                  <option value="effluent">Efluente</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm">Fecha de medición</label>
                <input type="datetime-local" value={measurementDate} onChange={e=>setMeasurementDate(e.target.value)} className="px-3 py-2 rounded border w-full bg-white dark:bg-gray-800" />
              </div>
              <div>
                <label className="block text-sm">Valor</label>
                <input type="number" step="0.01" value={value} onChange={e=>setValue(e.target.value)} className="px-3 py-2 rounded border w-full bg-white dark:bg-gray-800" />
              </div>
            </div>
            <button disabled={saving || !plantId || !measurementDate} onClick={saveMeasurement} className="px-3 py-2 rounded border bg-blue-600 text-white disabled:opacity-50">
              {saving ? 'Guardando...' : 'Guardar medición'}
            </button>
            <button disabled={saving || !plantId || !measurementDate} onClick={deleteMeasurement} className="ml-2 px-3 py-2 rounded border bg-red-600 text-white disabled:opacity-50">
              {saving ? 'Eliminando...' : 'Eliminar medición'}
            </button>
            {message && <div className="text-sm mt-2">{message}</div>}
            <div className="text-xs text-yellow-700 bg-yellow-50 border rounded p-2">
              Nota: requiere configurar Supabase en el servidor para persistencia. Si no está disponible, se usa almacenamiento local de demostración para estas acciones.
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded border p-4">
          <h2 className="text-lg font-medium mb-3">Otras gestiones</h2>
          <p className="text-gray-600">Gestión de usuarios, plantas y cronogramas (próximo).</p>
        </div>
      </div>
    </div>
  )
}