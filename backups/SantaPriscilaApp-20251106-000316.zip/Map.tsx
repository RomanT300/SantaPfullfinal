import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import { useEffect, useState } from 'react'

type Plant = {
  id: string
  name: string
  latitude: number
  longitude: number
  status: string
}

export default function MapPage() {
  const [plants, setPlants] = useState<Plant[]>([])
  const [adding, setAdding] = useState(false)
  const [newPlant, setNewPlant] = useState<{ name: string; location: string; latitude: number | null; longitude: number | null; status: string }>({
    name: '',
    location: '',
    latitude: null,
    longitude: null,
    status: 'active',
  })
  const [notice, setNotice] = useState<string | null>(null)
  useEffect(() => {
    fetch('/api/plants', { credentials: 'include' })
      .then(r => r.json())
      .then(json => { if (json.success) setPlants(json.data || []) })
      .catch(() => {})
  }, [])

  function ClickSetter({ enabled }: { enabled: boolean }) {
    useMapEvents({
      click(e) {
        if (!enabled) return
        setNewPlant(p => ({ ...p, latitude: e.latlng.lat, longitude: e.latlng.lng }))
      },
    })
    return null
  }

  const savePlant = async () => {
    setNotice(null)
    if (!newPlant.name || newPlant.latitude == null || newPlant.longitude == null) {
      setNotice('Completa nombre y selecciona coordenadas haciendo clic en el mapa.')
      return
    }
    try {
      const res = await fetch('/api/plants', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          name: newPlant.name,
          location: newPlant.location || `${newPlant.latitude}, ${newPlant.longitude}`,
          latitude: newPlant.latitude,
          longitude: newPlant.longitude,
          status: newPlant.status,
        }),
      })
      const json = await res.json()
      if (!json.success) throw new Error(json.error || 'Error')
      setPlants(prev => [...prev, json.data])
      setAdding(false)
      setNewPlant({ name: '', location: '', latitude: null, longitude: null, status: 'active' })
      setNotice('Planta guardada correctamente.')
    } catch (e: any) {
      // Fallback: mostrar marcador local si el backend no guarda
      const localPlant: Plant = {
        id: `local-${Date.now()}`,
        name: `${newPlant.name} (local)`,
        latitude: newPlant.latitude!,
        longitude: newPlant.longitude!,
        status: 'sincronizar',
      }
      setPlants(prev => [...prev, localPlant])
      setAdding(false)
      setNotice('No se pudo guardar en el backend. Marcador local añadido.')
    }
  }

  return (
    <div className="h-[calc(100vh-64px)] relative">
      {/* Panel de edición */}
      <div className="absolute top-3 left-3 z-[1000] bg-white dark:bg-gray-800 rounded border shadow p-3 w-80">
        <div className="flex items-center justify-between mb-2">
          <div className="font-semibold">Mapa de Plantas</div>
          <label className="text-sm flex items-center gap-1">
            <input type="checkbox" checked={adding} onChange={e=>setAdding(e.target.checked)} />
            Modo edición
          </label>
        </div>
        {adding && (
          <div className="space-y-2">
            <input className="w-full px-2 py-1 rounded border" placeholder="Nombre de planta" value={newPlant.name} onChange={e=>setNewPlant(p=>({...p, name: e.target.value}))} />
            <input className="w-full px-2 py-1 rounded border" placeholder="Ubicación (opcional)" value={newPlant.location} onChange={e=>setNewPlant(p=>({...p, location: e.target.value}))} />
            <div className="text-xs text-gray-600">Haz clic en el mapa para fijar coordenadas.</div>
            <div className="grid grid-cols-2 gap-2">
              <input className="px-2 py-1 rounded border" placeholder="Latitud" value={newPlant.latitude ?? ''} onChange={e=>setNewPlant(p=>({...p, latitude: Number(e.target.value)}))} />
              <input className="px-2 py-1 rounded border" placeholder="Longitud" value={newPlant.longitude ?? ''} onChange={e=>setNewPlant(p=>({...p, longitude: Number(e.target.value)}))} />
            </div>
            <button className="px-3 py-1 rounded border bg-blue-600 text-white" onClick={savePlant}>Guardar</button>
          </div>
        )}
        {notice && <div className="mt-2 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded px-2 py-1">{notice}</div>}
      </div>
      {/* Limitar navegación a Ecuador continental (solo Ecuador visible) */}
      <MapContainer
        center={[-1.8, -78.5]}
        zoom={7}
        minZoom={6}
        maxZoom={14}
        maxBounds={[[-5.0, -81.3], [1.5, -75.0]]}
        maxBoundsViscosity={1.0}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" />
        <ClickSetter enabled={adding} />
        {plants.map(p => (
          <Marker key={p.id} position={[p.latitude, p.longitude]}>
            <Popup>
              <div className="min-w-48">
                <div className="font-semibold">{p.name}</div>
                <div className="text-xs text-gray-500">Estado: {p.status}</div>
                <a className="text-blue-600 text-sm" href={`/documents?plant=${p.id}`}>Ver documentos</a>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}